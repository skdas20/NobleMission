<?php
// Load WordPress
require_once('wp-load.php');

// Pages to create
$pages = array(
    array(
        'post_title'    => 'About Us',
        'post_content'  => 'Welcome to the About Us page.',
        'post_type'     => 'page',
        'post_status'   => 'publish',
        'page_template' => 'page-about.php'
    ),
    array(
        'post_title'    => 'Gallery',
        'post_content'  => 'Check out our gallery.',
        'post_type'     => 'page',
        'post_status'   => 'publish',
        'page_template' => 'page-gallery.php'
    ),
    array(
        'post_title'    => 'Impact',
        'post_content'  => 'See our impact on the community.',
        'post_type'     => 'page',
        'post_status'   => 'publish',
        'page_template' => 'page-impact.php'
    ),
    array(
        'post_title'    => 'FAQ',
        'post_content'  => 'Frequently asked questions.',
        'post_type'     => 'page',
        'post_status'   => 'publish',
        'page_template' => 'page-faq.php'
    ),
    array(
        'post_title'    => 'Contact',
        'post_content'  => 'Get in touch with us.',
        'post_type'     => 'page',
        'post_status'   => 'publish',
        'page_template' => 'page-contact.php'
    ),
);

// Create pages
foreach ($pages as $page) {
    $template = $page['page_template'];
    unset($page['page_template']);
    
    $page_id = wp_insert_post($page);
    
    if ($page_id) {
        update_post_meta($page_id, '_wp_page_template', $template);
        echo "Created page: " . $page['post_title'] . " (ID: $page_id) with template: $template\n";
    } else {
        echo "Failed to create page: " . $page['post_title'] . "\n";
    }
}

// Create sample blog posts for Insights
$blog_posts = array(
    array(
        'post_title'   => 'Welcome to Noble Mission Blog',
        'post_content' => 'This is our first blog post. We are excited to share updates about our school and the amazing work we do with our students.',
        'post_type'    => 'post',
        'post_status'  => 'publish',
        'post_excerpt' => 'Welcome to our blog where we share updates and stories.'
    ),
    array(
        'post_title'   => 'Student Success Stories',
        'post_content' => 'Learn about the incredible achievements of our students and how they are making a difference in their communities.',
        'post_type'    => 'post',
        'post_status'  => 'publish',
        'post_excerpt' => 'Discover inspiring stories of student success.'
    ),
    array(
        'post_title'   => 'New Programs and Initiatives',
        'post_content' => 'We are launching new programs to better serve our students. Read about the exciting changes coming to Noble Mission.',
        'post_type'    => 'post',
        'post_status'  => 'publish',
        'post_excerpt' => 'Discover our new initiatives.'
    ),
);

echo "\n--- Creating Blog Posts ---\n";
foreach ($blog_posts as $post) {
    $post_id = wp_insert_post($post);
    
    if ($post_id) {
        // Add featured image (using placeholder URL)
        $attachment_id = media_sideload_image('https://images.unsplash.com/photo-1503454537195-1dcabb73ffb9?w=500&h=300&fit=crop', $post_id, 'Featured Image', 'id');
        
        if ($attachment_id) {
            set_post_thumbnail($post_id, $attachment_id);
        }
        
        echo "Created post: " . $post['post_title'] . " (ID: $post_id)\n";
    } else {
        echo "Failed to create post: " . $post['post_title'] . "\n";
    }
}

echo "\nAll pages and posts created successfully!\n";
?>
